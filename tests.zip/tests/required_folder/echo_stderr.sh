#!/bin/bash

echo $@ >&2
